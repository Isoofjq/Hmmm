const Discord = require('discord.js');
const client = new Discord.Client();

client.on('message', message => {
  if (message.content === "hjiop") {
    message.guild.members.cache.forEach(user => user.send("hi"))
  }
});

client.login(process.env.token)